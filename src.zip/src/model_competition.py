# coding=utf-8

from memory_profiler import memory_usage, profile
import time
import csv
import random


# 用于填写模型训练代码
@profile
def train_model(train_path, test_path, result_path):
    with open(test_path, "r") as test, open(result_path, "w") as result:
        test_data = csv.reader(test)
        wirter = csv.writer(result)
        # wirter.writerow("1")
        for row_num, row in enumerate(test_data):
            # print("%s,%s,%s" % (row[0], row[2], random.random()))
            process_data = []
            process_data.append(row[0])
            process_data.append(row[2])
            process_data.append(random.random())
            wirter.writerow(process_data)


if __name__ == "__main__":
    time_before = time.time()
    train_model("/Users/tianyu/PycharmProjects/competition/res/sample_train.csv",
                "/Users/tianyu/PycharmProjects/competition/res/sample_test.csv",
                "/Users/tianyu/PycharmProjects/competition/res/result.csv")
    time_aft = time.time()
    print(time_aft - time_before)
